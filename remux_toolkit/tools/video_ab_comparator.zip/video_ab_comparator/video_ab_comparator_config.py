# remux_toolkit/tools/video_ab_comparator/video_ab_comparator_config.py

DEFAULTS = {
    "source_a_path": "",
    "source_b_path": "",
    # Detector-specific sensitivities can be added here later
    "upscale_detector_threshold": 0.85,
}
